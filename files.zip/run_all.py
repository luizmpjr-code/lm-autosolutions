from scraper_olx import scrape_olx, salvar_json
from commit_github import commit_estoque

print("=" * 50)
print("LM AutoSolutions — Sincronização de estoque")
print("=" * 50)

veiculos = scrape_olx()

if veiculos:
    salvar_json(veiculos)
    commit_estoque()
    print(f"\n✅ {len(veiculos)} veículos sincronizados com o site")
else:
    print("\n⚠ Nenhum veículo encontrado — site mantém estoque anterior")
