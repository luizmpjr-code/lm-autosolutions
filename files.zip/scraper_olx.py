import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime

PERFIL_URL = "https://www.olx.com.br/perfil/luiz-miguel-autosolutions-18546a8c"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/120.0.0.0 Safari/537.36",
    "Accept-Language": "pt-BR,pt;q=0.9",
}

def scrape_olx():
    veiculos = []
    try:
        r = requests.get(PERFIL_URL, headers=HEADERS, timeout=15)
        soup = BeautifulSoup(r.text, "html.parser")

        cards = soup.select("li[data-lurker-detail='list_id']")
        if not cards:
            cards = soup.select("ul.sc-1fcmfeb-2 li")

        for card in cards:
            try:
                titulo = card.select_one("h2, .fnmrjs-0, [class*='title']")
                titulo = titulo.get_text(strip=True) if titulo else ""

                preco = card.select_one("p[class*='price'], .sc-ifAKCX, [class*='price']")
                preco = preco.get_text(strip=True) if preco else "Consulte"

                link = card.select_one("a")
                link = link["href"] if link and link.get("href") else PERFIL_URL

                img = card.select_one("img")
                img_url = ""
                if img:
                    img_url = img.get("src") or img.get("data-src") or ""

                detalhes = card.select("[class*='detail'], [class*='property']")
                det_texto = " · ".join([d.get_text(strip=True) for d in detalhes[:3]])

                if titulo:
                    veiculos.append({
                        "titulo": titulo,
                        "preco": preco,
                        "detalhes": det_texto,
                        "link": link if link.startswith("http") else "https://www.olx.com.br" + link,
                        "imagem": img_url,
                        "atualizado": datetime.now().strftime("%d/%m/%Y %H:%M")
                    })
            except Exception as e:
                print(f"Erro no card: {e}")
                continue

    except Exception as e:
        print(f"Erro ao acessar OLX: {e}")

    return veiculos

def salvar_json(veiculos, path="estoque.json"):
    dados = {
        "atualizado": datetime.now().strftime("%d/%m/%Y às %H:%M"),
        "total": len(veiculos),
        "veiculos": veiculos
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)
    print(f"✓ {len(veiculos)} veículos salvos em {path}")

if __name__ == "__main__":
    print("Raspando OLX...")
    veiculos = scrape_olx()
    salvar_json(veiculos)
