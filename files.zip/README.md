# LM AutoSolutions

Site oficial da LM AutoSolutions — especialistas em compra, venda e consultoria automotiva desde 1991.

**URL:** https://lmautosolutions.tech

## Estrutura

```
lm-autosolutions/
├── index.html          # Site principal
├── estoque.json        # Estoque atualizado automaticamente pelo Open Claw
├── scraper_olx.py      # Raspa anúncios do perfil OLX
├── commit_github.py    # Envia estoque.json para o GitHub
├── run_all.py          # Executa scraper + commit (agendar no Open Claw)
└── README.md
```

## Atualização automática do estoque

O Open Claw roda `run_all.py` a cada 6 horas:
1. Raspa os anúncios ativos do perfil OLX da LM AutoSolutions
2. Salva em `estoque.json`
3. Faz commit no GitHub
4. Netlify detecta o commit e faz deploy automático em ~30 segundos

## Configuração

1. Instalar dependências: `pip install requests beautifulsoup4`
2. Gerar token GitHub em: Settings → Developer settings → Personal access tokens → repo
3. Colar token em `commit_github.py`
4. Agendar no Open Claw: `0 */6 * * * python /caminho/run_all.py`

## Contato

WhatsApp: (21) 96811-1066  
Instagram: @lm_autosolutions  
OLX: https://www.olx.com.br/perfil/luiz-miguel-autosolutions-18546a8c
