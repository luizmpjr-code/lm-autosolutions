import requests
import json
import base64
from datetime import datetime

# ── Configure aqui ──────────────────────────────────────────
GITHUB_TOKEN = "SEU_TOKEN_AQUI"   # github.com → Settings → Developer settings → Tokens (classic) → repo
REPO_OWNER   = "luizmpjr-code"
REPO_NAME    = "lm-autosolutions"
FILE_PATH    = "estoque.json"
# ────────────────────────────────────────────────────────────

def commit_estoque(json_path="estoque.json"):
    with open(json_path, "r", encoding="utf-8") as f:
        conteudo = f.read()

    conteudo_b64 = base64.b64encode(conteudo.encode()).decode()

    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{FILE_PATH}"
    headers = {
        "Authorization": f"token {GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }

    # Verifica SHA do arquivo existente
    r = requests.get(url, headers=headers)
    sha = r.json().get("sha") if r.status_code == 200 else None

    payload = {
        "message": f"Estoque atualizado — {datetime.now().strftime('%d/%m/%Y %H:%M')}",
        "content": conteudo_b64,
    }
    if sha:
        payload["sha"] = sha

    resp = requests.put(url, headers=headers, json=payload)
    if resp.status_code in [200, 201]:
        print("✓ estoque.json enviado ao GitHub — Netlify fará deploy automático")
    else:
        print(f"Erro GitHub: {resp.status_code} — {resp.text[:300]}")

if __name__ == "__main__":
    commit_estoque()
